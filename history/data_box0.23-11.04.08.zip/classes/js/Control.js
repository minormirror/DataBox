

/*####################################################### Control ###################################################*/

function Control(parent_element_id){
  this.maxX;
  this.minX;
  this.maxY;
  this.minY;
  
  
  this.currElement;
  this.currOffsetX;
  this.currOffsetY;
  this.currElementOffsetX;
  this.currElementOffsetY;
  this.currState = "NO_ACTION";
  this.parent_element_id = parent_element_id;  //'cont'
  this.infoBoxList = new Array();
  this.ibDummy = new IBDummyElement();
  this.subversion = 0;
  this.lastEvent;


  document.getElementById(this.parent_element_id).appendChild(this.ibDummy.div_element);

  this.setFocus = function(div_element){
    function focusSort(a,b){
      var za = a.style.zIndex;
	  var zb = b.style.zIndex;

      if (za == ""){ za = "0"; }
      if (zb == ""){ zb = "0"; }
      return za - zb;
    }

    var sub = new Array();
	var parent = document.getElementById(this.parent_element_id);
	for(var i=0;i<parent.childNodes.length;i++){
	  sub.push(parent.childNodes[i]);
	}

	sub.sort(focusSort);

	for(var i=0;i<sub.length;i++){
	  if (sub[i] == div_element){
	    sub[i].style.zIndex = sub.length+1;
	  }else{
	    sub[i].style.zIndex = i;
	  }
	}
  }

  this.startArrow = function (ib,ev){
  var newarrow = new Arrow(this,this.lastEvent);
	newarrow.setEndPos(ev.clientX+5,ev.clientY+5);
	newarrow.startIb = ib;
	ib.arrowList.push(newarrow);
	ib.refreshArrows();
	this.currElement = newarrow;
  }

  this.deleteArrow = function(arrow){
    arrow.deleteArrow();
  }

  this.addTextBox = function (){
    var newib = new InfoBox(this);
	this.infoBoxList.push(newib);
    document.getElementById(this.parent_element_id).appendChild(newib.div_element);
	this.setState("NO_ACTION");
    return newib;
  }
  
  this.deleteTextBox = function(ib){
    check = confirm("Wollen Sie dieses Element("+ib.id+") endg�ltig l�schen ?");
    if (check){  
	/*
	 
	  */
	}
  }

  this.getInfoBoxByDIV = function (div){
    var cont = document.getElementById(this.parent_element_id);
	var c = 0;
	for (var i=0;i<this.infoBoxList.length;i++){
	  if (this.infoBoxList[i].div_element == div){
	    return this.infoBoxList[i];
	  }
	}
  }


  this.drag_infobox = function(ev){
    this.currElement.style.left = ev.clientX-this.currElementOffsetX;
    this.currElement.style.top = ev.clientY-this.currElementOffsetY;
  }


  this.resize_infobox = function(ev){
    var new_width = ev.clientX-this.currOffsetX;
    if (new_width < 160){
      new_width = 160;
    }
    this.currElement.style.width = new_width;
    var new_height = ev.clientY-this.currOffsetY;
    if (new_height < 120){
      new_height = 120;
    }
    this.currElement.childNodes[0].childNodes[1].childNodes[0].childNodes[0].style.height = (new_height-30)+"px";
  }


  this.fly_arrow = function(ev){
    this.currElement.setEndPos(ev.clientX+5,ev.clientY+5);
  }

  this.focusInfoBoxes = function(){
    var max = 0;
	var parent = document.getElementById(this.parent_element_id);
	for(var i=0;i<parent.childNodes.length;i++){
	  max = Math.max(max,parent.childNodes[i].style.zIndex);
	}
	for(var i=0;i<this.infoBoxList.length;i++){
	  this.infoBoxList[i].div_element.style.zIndex += max;
	}
  }

  this.getIBByID = function(id){
    for (var i=0;i<this.infoBoxList.length;i++){
	  if (this.infoBoxList[i].id == id){
	    return this.infoBoxList[i];
	  }
	}
	return null;
  }


  this.onmousemove = function (ev){ return this.eventSwitch("BOARD_MOUSEMOVE",this,ev); }

  this.onmouseup = function (ev){ return this.eventSwitch("BOARD_MOUSEUP",this,ev); }

  this.setState = function (newstate){
    setState(newstate);
    this.currState = newstate;
  }

  this.getLastEvent = function(){
    return this.lastEvent;
  }

 /* eventSwitch(event,obj,ev)
  *
  * Diese Methode schaltet den globalen Zustand des Controls weiter. Der Zustand steht in der Klassen-Variable currState des Control-Objektes.
  * Dabei wird je nachdem welcher Zustand aktuell vorliegt in Abh�ngigkeit des eintretenden event die zugeh�rige Aktion
  * und der zuk�nfige Zustand ausgew�hlt.
  */
  this.eventSwitch = function(event,obj,ev){
    setEvent(event);

    if (event == "INFO_BOX_HEAD_MOUSEDOWN"){
      if (this.currState == "NO_ACTION"){
        this.setState("DRAG_INFOBOX");
	      obj.startDrag(ev);
        this.ibDummy.show(this.currElement.offsetLeft,this.currElement.offsetTop,this.currElement.offsetWidth,this.currElement.offsetHeight);
      }
    }
    /*--------------------------------------------------------------------------------J�rn-------------------------------------------------------------*/
    else if ((event == "INFO_BOX_ARROW_BTN_MOUSECLICK_CONT") || (event == "INFO_BOX_ARROW_BTN_MOUSECLICK_QUEST") || (event == "INFO_BOX_ARROW_BTN_MOUSECLICK_MARK")){
      this.lastEvent = event;
      if (this.currState == "NO_ACTION"){
        obj.bc.startArrow(obj,ev);      
        this.currElement.setArrowFocus();
        this.setFocus(obj.div_element);
        this.setState("FLY_ARROW");
      }
      return true;
    }
    
    
    else if (event == "INFO_BOX_ACT_BTN_MOUSECLICK"){
      if (this.currState == "NO_ACTION"){
        if (!obj.isAct){
          msg = new Array();
          if (obj.unActArrow != null){
            if (obj.unActArrow.isDBObject){
              msg.push("5");//hier ende --- mit connect. l�ufts noch nich, soll so �hnlich laufen wie ibs, aus der superquery noch den remove=0 where rausnehmen und wenn con oder ib gel�scht wird eine botschaft an atrans schicken und der alle andere informieren
              msg.push(""+obj.unActArrow.id);
              msg.push(""+obj.unActArrow.startIb.id);
              msg.push(""+obj.unActArrow.endIb.id);
            }else{
              msg.push("4");
              msg.push(""+obj.unActArrow.id);
              msg.push(""+obj.unActArrow.startIb.id);
              msg.push(""+obj.unActArrow.endIb.id);
            }
          }else{
            if (obj.isDBObject){
              msg.push("3");
              msg.push(""+obj.id);
              msg.push(""+obj.textbox.value);
              msg.push(""+obj.div_element.offsetLeft);
              msg.push(""+obj.div_element.offsetTop);
              msg.push(""+obj.div_element.offsetWidth);
              msg.push(""+obj.div_element.offsetHeight);
            }else{
              msg.push("2");
              msg.push(""+obj.id);
              msg.push(""+obj.textbox.value);
              msg.push(""+obj.div_element.offsetLeft);
              msg.push(""+obj.div_element.offsetTop);
              msg.push(""+obj.div_element.offsetWidth);
              msg.push(""+obj.div_element.offsetHeight);
            }
          }
          send(msg);
        }
      }
      return false;
    } else if (event == "INFO_BOX_DEL_BTN_MOUSEDOWN"){ //###############################################################Joern##################################################
      if (this.currState == "NO_ACTION"){
        check = confirm("Wollen Sie dieses Element("+obj.id+") endg�ltig l�schen ?");
        if (check){  
          msg = new Array();
          msg.push("6");
          msg.push(""+obj.id);		  
          send(msg);
        }
        //this.deleteTextBox(obj);		
        return false;
      }
    }else if (event == "INFO_BOX_RESIZE_BTN_MOUSEDOWN"){
      if (this.currState == "NO_ACTION"){
        obj.resizeInfoBox(ev);
        this.setState("RESIZE_INFOBOX");
        this.ibDummy.show(this.currElement.offsetLeft,this.currElement.offsetTop,this.currElement.offsetWidth,this.currElement.offsetHeight);
        return false;
      }
        }else if (event == "INFO_BOX_MOUSEUP"){
          if(this.currState == "FLY_ARROW"){
            if (obj.isNewArrowAllowed(this.currElement)){
              obj.endArrow(ev);
              this.focusInfoBoxes();
            }else{
              this.deleteArrow(this.currElement);
            }
              this.setFocus(obj.div_element);
              this.setState("NO_ACTION");
              return false;
            }
          }else if (event == "INFO_BOX_MOUSEDOWN"){
            this.setFocus(obj.div_element);
          }else if (event == "BOARD_MOUSEUP"){
            if (this.currState == "DRAG_INFOBOX") {
              this.getInfoBoxByDIV(this.currElement).refreshArrows();
              this.ibDummy.hide();
              this.setState("NO_ACTION");
            }else if (this.currState == "RESIZE_INFOBOX"){
              this.getInfoBoxByDIV(this.currElement).refreshArrows();
              this.ibDummy.hide();
              this.setState("NO_ACTION");
            }else if(this.currState == "FLY_ARROW"){
              this.deleteArrow(this.currElement);
              this.setState("NO_ACTION");
            }
          }else if (event == "BOARD_MOUSEMOVE"){
            if (this.currState == "DRAG_INFOBOX"){
              obj.drag_infobox(ev);
            }else if (this.currState == "RESIZE_INFOBOX"){
              obj.resize_infobox(ev);
            }else if (this.currState == "FLY_ARROW"){
              obj.fly_arrow(ev);
            }
          }
        return true;
        }

  }


