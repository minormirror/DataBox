/*####################################################### InfoBox ###################################################*/

function sortArray0(a,b){
  var oia = a.getOpposite();
  var oib = b.getOpposite();
  if ((oia != null) && (oib != null)){
	return oia.getCenterPos()[0] - oib.getCenterPos()[0];
  }else{
	return -1;
  }
}

function sortArray1(a,b){
  var oia = a.getOpposite();
  var oib = b.getOpposite();
  if ((oia != null) && (oib != null)){
	return oia.getCenterPos()[1] - oib.getCenterPos()[1];
  }else{
	return -1;
  }
}

function sortArray2(a,b){
  var oia = a.getOpposite();
  var oib = b.getOpposite();
  if ((oia != null) && (oib != null)){
	return oib.getCenterPos()[0]-oia.getCenterPos()[0];
  }else{
	return -1;
  }
}

function sortArray3(a,b){
  var oia = a.getOpposite();
  var oib = b.getOpposite();
  if ((oia != null) && (oib != null)){
	return oib.getCenterPos()[1] - oia.getCenterPos()[1];
  }else{
	return -1;
  }
}


function InfoBox(bc){
  this.bc = bc;
  this.arrowList = new Array();

  this.id = randomId();
  this.project_id = 0;
  this.version = 0;
  this.subversion = 0;
  this.isDBObject = false;
  this.isAct = false;
  this.dbstring = "";

  this.unActArrow = null;

  this.div_element = document.createElement("div");
  var tab = document.createElement("table");
  tab.width = "100%";
  tab.height = "100%";
  tab.cellSpacing="0px";
  tab.cellPadding ="0px";

  this.tr1 = document.createElement("tr");
  this.tr1.style.backgroundColor ="#79d5e0";

  this.tr1onmousedown = function (ev){ return this.bc.eventSwitch("INFO_BOX_HEAD_MOUSEDOWN",this,ev);}
  this.tr1.onmousedown = this.tr1onmousedown.bindAsEventListener(this);

  var td1 = document.createElement("td");
  var td_1 = document.createElement("td");

  /*var img1 = document.createElement("img");
  img1.src = "resources/icons/pfeil_ico.png";
  /*this.img1onclick = function (ev){  return this.bc.eventSwitch("INFO_BOX_ARROW_BTN_MOUSECLICK",this,ev); }
  img1.onclick = this.img1onclick.bindAsEventListener(this);
  td1.appendChild(img1);*/

  var img2 = document.createElement("img");
  img2.src = "resources/icons/saved_nein.png";
  this.img2onclick = function (ev){  return this.bc.eventSwitch("INFO_BOX_ACT_BTN_MOUSECLICK",this,ev); }
  img2.onclick = this.img2onclick.bindAsEventListener(this);
  td1.appendChild(img2);

  /* Best�tigungs Button */
  var img3 = document.createElement("img");
  img3.src = "resources/icons/ausrufezeichen_button_ico.png";
  this.img3onclick = function (ev){  return this.bc.eventSwitch("INFO_BOX_ARROW_BTN_MOUSECLICK",this,ev); }
  img3.onclick = this.img3onclick.bindAsEventListener(this);
  td1.appendChild(img3);

  /* Widerspruch Button */
  var img4 = document.createElement("img");
  img4.src = "resources/icons/blitz_button_ico.png";
  td1.appendChild(img4);

  /* Frage Button */
  var img5 = document.createElement("img");
  img5.src = "resources/icons/frage_button_ico.png";
  td1.appendChild(img5);

    /* Loeschen Button */
  var img6 = document.createElement("img");
  img6.src = "resources/icons/loesch_button_ico.png";
  var td2 = document.createElement("td");
  var td_spalteX_ausrichtung = document.createAttribute("align");
  td_spalteX_ausrichtung.nodeValue = "right";
  td2.setAttributeNode(td_spalteX_ausrichtung);
  this.img6onclick = function (ev){  return this.bc.eventSwitch("INFO_BOX_DEL_BTN_MOUSEDOWN",this,ev); }
  img6.onclick = this.img6onclick.bindAsEventListener(this);

  td2.appendChild(img6);
  this.tr1.appendChild(td1);
  this.tr1.appendChild(td2);
  tab.appendChild(this.tr1);

  var tr2 = document.createElement("tr");
  var td2 = document.createElement("td");
  var spalten_verbinden = document.createAttribute("colspan");
  spalten_verbinden.nodeValue = "2";
  td2.setAttributeNode(spalten_verbinden);
  this.textbox = document.createElement("textarea");
  this.textbox.style.width="100%";
  this.textbox.style.height="120px";
  this.textbox.style.border="solid 1px #aaaaaa;";
  this.textbox.style.fontSize = "0.8em";
  this.textbox.style.fontFamily = "Verdana, Arial, sans-serif";
  this.textbox.style.backgroundColor ="#fbf9eb";
  td2.appendChild(this.textbox);
  tr2.appendChild(td2);
  tab.appendChild(tr2);

  this.textboxonkeyup = function (ev){ this.setAct(this.textbox.value == this.dbstring);}
  this.textbox.onkeyup  = this.textboxonkeyup.bindAsEventListener(this);

  var tr3 = document.createElement("tr");
  var td3 = document.createElement("td");
  var spalten_verbinden3 = document.createAttribute("colspan");
  spalten_verbinden3.nodeValue = "2";
  td3.setAttributeNode(spalten_verbinden3);
  td3.style.textAlign="right";
  var img = document.createElement("img");
  img.src = "resources/icons/groesse.png";
  this.headImgMouseDownHandler = function (ev){ return this.bc.eventSwitch("INFO_BOX_RESIZE_BTN_MOUSEDOWN",this,ev);}
  img.onmousedown = this.headImgMouseDownHandler.bindAsEventListener(this);
  td3.appendChild(img);
  tr3.appendChild(td3);
  tab.appendChild(tr3);
  this.div_element.appendChild(tab);
  this.div_element.style.border="solid 1px #000000;";
  this.div_element.style.position="absolute";
  this.div_element.style.width = "160px";
  this.div_element.style.backgroundColor = "#e7e5d7";


  this.isNewArrowAllowed = function(arrow){
    return (arrow.startIb != this);
  }

  this.setCursor = function(cursor){
    var cursor = "default";
    if (this.bc.currState == "FLY_ARROW"){
	  if (this.isNewArrowAllowed(this.bc.currElement)){
	    cursor = "pointer";
	  }else{
	    cursor = "not-allowed";
	  }
	}

    this.div_element.style.cursor =cursor;
   	this.tr1.style.cursor =cursor;
	if (cursor == "default"){
	  cursor ="text";
	}
	this.textbox.style.cursor =cursor;
  }

  this.setAct = function(isAct){
    this.isAct = isAct;
	if (isAct){
	  img2.src = "resources/icons/saved_ja.png";
	}else{
	  img2.src = "resources/icons/saved_nein.png";
	}
  }

  this.div_element_onmousemove = function(ev){
    this.setCursor();
  }
  this.div_element.onmousemove = this.div_element_onmousemove.bindAsEventListener(this);


  this.setzeText = function(message){
    this.textbox.value = message;
  }


  this.div_element_onmouseover = function(ev){
    this.div_element.style.backgroundColor = "#fbf9e9";
	this.tr1.style.backgroundColor ="#b0f7ff";
	this.textbox.style.backgroundColor ="#ffffff";

	this.setCursor();
  }
  this.div_element.onmouseover = this.div_element_onmouseover.bindAsEventListener(this);

  this.div_element_onmouseout = function(ev){
    this.div_element.style.backgroundColor = "#e7e5d7";
	this.tr1.style.backgroundColor ="#79d5e0";
	this.textbox.style.backgroundColor ="#fbf9eb";

  }
  this.div_element.onmouseout = this.div_element_onmouseout.bindAsEventListener(this);



  this.div_element_onmouseup = function(ev){
    var res = this.bc.eventSwitch("INFO_BOX_MOUSEUP",this,ev);
	this.setCursor();
	return res;
  }
  this.div_element.onmouseup = this.div_element_onmouseup.bindAsEventListener(this);

  this.div_element_onmousedown = function(ev){ return this.bc.eventSwitch("INFO_BOX_MOUSEDOWN",this,ev);}
  this.div_element.onmousedown = this.div_element_onmousedown.bindAsEventListener(this);


  /*- functions -*/

  this.getPos = function(){    //Reihenfolge linksoben - rechtsunten - center
	return new Array(	new Array(this.div_element.offsetLeft,this.div_element.offsetTop),
						new Array(this.div_element.offsetLeft+this.div_element.offsetWidth,this.div_element.offsetTop+this.div_element.offsetHeight),
						new Array(this.div_element.offsetLeft+this.div_element.offsetWidth/2,this.div_element.offsetTop+this.div_element.offsetHeight/2)
	);
  }

   this.getCenterPos = function(){    //Reihenfolge linksoben - rechtsunten - center
	 return new Array(this.div_element.offsetLeft+this.div_element.offsetWidth/2,this.div_element.offsetTop+this.div_element.offsetHeight/2);
  }

  this.resizeInfoBox = function(ev){
    var currTarget = ev.target;
    this.bc.currElement = this.div_element;
    this.bc.currElementOffsetX = ev.clientX-this.div_element.offsetLeft;
    this.bc.currElementOffsetY = ev.clientY-this.div_element.offsetTop;
    this.bc.currOffsetX = this.div_element.offsetLeft;
    this.bc.currOffsetY = this.div_element.offsetTop;
	this.setAct(false);
  }

  this.refreshArrows = function (){
    this.refreshArrowPos();
	for(var i=0;i<this.arrowList.length;i++){
	  var oib = this.arrowList[i].getOpposite();
	  if(oib != null){
	    oib.refreshArrowPos();
      }
	}
  }


  this.refreshArrowPos = function(){
    //unterscheidung bei Berechnung der pfeil start/endposition
	// 1: der Pfeil geht direkt von IB zu IB => berechnung nach algouml
	// 2: der Pfeil der Pfeil l�uft von IB zu Arrow-Node =>


	for(var i=0;i<this.arrowList.length;i++){
	  this.arrowList[i].setPos(this,unpx(this.div_element.style.left)+(this.div_element.offsetWidth/2),unpx(this.div_element.style.top)+(this.div_element.offsetHeight/2));
	}

	var site_0=new Array();
	var site_1=new Array();
	var site_2=new Array();
	var site_3=new Array();
	var nosite=new Array();
	for(var i=0;i<this.arrowList.length;i++){
	  this.arrowList[i].setSelectedIb(this);
	  var site = this.arrowList[i].getSite();

	  if (site==0){
	    site_0.push(this.arrowList[i]);
	  }else if (site==1){
	    site_1.push(this.arrowList[i]);
	  }else if (site==2){
	    site_2.push(this.arrowList[i]);
	  }else if (site==3){
	    site_3.push(this.arrowList[i]);
	  }else{
	    nosite.push(this.arrowList[i]);
	  }
	}

	var pos = this.getPos();

	var step = 20;


	if (site_0.length >0){
	  site_0.sort(sortArray0);
	  var hl = ((site_0.length-1)*step)/2;
	  for(var i=0;i<site_0.length;i++){
	    site_0[i].setPos(this,pos[2][0]-hl+i*step,pos[0][1]);
	  }

	}

	if (site_1.length >0){
	  site_1.sort(sortArray1);
	  var hl = ((site_1.length-1)*step)/2;
	  for(var i=0;i<site_1.length;i++){
	    site_1[i].setPos(this,pos[1][0],pos[2][1]-hl+i*step);
	  }
	}

	if (site_2.length >0){
	  site_2.sort(sortArray2);
	  var hl = ((site_2.length-1)*step)/2;
	  for(var i=0;i<site_2.length;i++){
	    site_2[i].setPos(this,pos[2][0]+hl-i*step,pos[1][1]);
	  }
	}

	if (site_3.length >0){
	  site_3.sort(sortArray3);
	  var hl = ((site_3.length-1)*step)/2;
	  for(var i=0;i<site_3.length;i++){
	    site_3[i].setPos(this,pos[0][0],pos[2][1]+hl-i*step);
	  }
	}
  }

  this.setText = function(txt){
    this.content.value = txt;
  }

  this.endArrow = function(ev){
    this.bc.currElement.endIb = this;
	this.arrowList.push(this.bc.currElement);
	this.bc.currElement.startIb.unActArrow = this.bc.currElement;
	this.refreshArrows();
  }

  this.startDrag = function(ev){
    this.bc.currElement =  this.div_element;

    this.bc.currElementOffsetX = ev.clientX-this.div_element.offsetLeft;
    this.bc.currElementOffsetY = ev.clientY-this.div_element.offsetTop;

	this.bc.setFocus(this.div_element);
	this.setAct(false);
  }
}

