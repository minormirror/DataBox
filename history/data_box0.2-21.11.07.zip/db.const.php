<?
$host = 'rdbms.strato.de';
$user = 'U320859';
$password = 'saufen2805';
$db = 'DB320859';
?>