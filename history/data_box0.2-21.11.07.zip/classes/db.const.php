<?
$error_list = "";

function connectDB(){
  $host = 'rdbms.strato.de';
  $user = 'U320859'; 
  $password = 'saufen2805';
  $db = 'DB320859';

  $connectionid = mysql_connect($host, $user , $password)  or die("\n Keine Verbindung m�glich: " . mysql_error());
  if (!mysql_select_db ($db, $connectionid)) { 
    die ("\n Auswahl der Datenbank fehlgeschlagenk"); 
  } 
}
?>