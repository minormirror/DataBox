<?
include_once("db.const.php");

function response_failed(){
  echo "0";
}

function response_msg($msg){
  echo "1#";
  echo $msg;
}

$req = $_REQUEST["r"];
/*  a #
 *  a = commandnr: 1 = get changeid
 *
 */

$reqa = explode("#", $req);

$cmd = (int)$reqa[0];

mysql_connect($host, $user , $password)  or die("\n Keine Verbindung m�glich: " . mysql_error());
mysql_select_db($db) or die("\n Auswahl der Datenbank fehlgeschlagen");


if ($cmd == 1){
  $query = "SELECT * FROM ib_projectpage WHERE id=1";
  $result = mysql_query($query) or die("Anfrage fehlgeschlagen: " . mysql_error());
  $line = mysql_fetch_array($result, MYSQL_ASSOC);
  response_msg($line["changeid"]);
  mysql_free_result($result);
}


mysql_close();

?>