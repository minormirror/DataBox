<?php
  include_once("boxcontainer.php");
  
  $width = 180;    
  $height = 130; 

  function fillRects($im,$col){     
    $width = 180;    
    $height = 130; 
    //das menue darstellen //sollte eigentlich in das div des MapNavigator.js
    //draw_roundrectangle($im, 135, 5, 174, 30, 3 , $col, 1);
    //nun die divs    
    $minmax = getBoxMinMax();
    $rel_width = $minmax[1]; //-$minmax[0]
    $rel_height = $minmax[3];//-$minmax[2]
    for ($i=0;$i<getBoxSize();$i++){
      $box = getBoxAt($i);
      //echo "id : ".$box[0];
      $rel_x1 = ($box[1]/$rel_width)*$width;
      $rel_x1 = floor($rel_x1);
      $rel_y1 = ($box[2]/$rel_height)*$height;
      $rel_y1 = floor($rel_y1);
      $rel_x2 = $rel_x1+(($box[3]/$rel_width)*$width);
      $rel_x2 = floor($rel_x2);
      $rel_y2 = $rel_y1+(($box[4]/$rel_height)*$height);      
      $rel_y2 = floor($rel_y2);      
      ImageString ($im, 2, $rel_x1, $rel_y1, $box[0], $col);
      imagerectangle($im, $rel_x1, $rel_y1, $rel_x2, $rel_y2, $col);
    }
  }

  function draw_roundrectangle($img, $x1, $y1, $x2, $y2, $radius, $color,$filled=1) {
      if ($filled==1){
          imagefilledrectangle($img, $x1+$radius, $y1, $x2-$radius, $y2, $color);
          imagefilledrectangle($img, $x1, $y1+$radius, $x1+$radius-1, $y2-$radius, $color);
          imagefilledrectangle($img, $x2-$radius+1, $y1+$radius, $x2, $y2-$radius, $color);

          imagefilledarc($img,$x1+$radius, $y1+$radius, $radius*2, $radius*2, 180 , 270, $color, IMG_ARC_PIE);
          imagefilledarc($img,$x2-$radius, $y1+$radius, $radius*2, $radius*2, 270 , 360, $color, IMG_ARC_PIE);
          imagefilledarc($img,$x1+$radius, $y2-$radius, $radius*2, $radius*2, 90 , 180, $color, IMG_ARC_PIE);
          imagefilledarc($img,$x2-$radius, $y2-$radius, $radius*2, $radius*2, 360 , 90, $color, IMG_ARC_PIE);
      }else{
          imageline($img, $x1+$radius, $y1, $x2-$radius, $y1, $color);
          imageline($img, $x1+$radius, $y2, $x2-$radius, $y2, $color);
          imageline($img, $x1, $y1+$radius, $x1, $y2-$radius, $color);
          imageline($img, $x2, $y1+$radius, $x2, $y2-$radius, $color);

          imagearc($img,$x1+$radius, $y1+$radius, $radius*2, $radius*2, 180 , 270, $color);
          imagearc($img,$x2-$radius, $y1+$radius, $radius*2, $radius*2, 270 , 360, $color);
          imagearc($img,$x1+$radius, $y2-$radius, $radius*2, $radius*2, 90 , 180, $color);
          imagearc($img,$x2-$radius, $y2-$radius, $radius*2, $radius*2, 360 , 90, $color);
      }               
  }

  header ("Content-type: image/png");
  $im = @ImageCreate (180, 130)
        or die ("kein gd -Stream moeglich");
  $background_color = ImageColorAllocate ($im, 250, 250, 250);
  $paint_color = ImageColorAllocate ($im, 47, 51, 114);
  $text_color = ImageColorAllocate ($im, 233, 14, 91);
  fillRects($im,$paint_color);
  ImageString ($im, 5, 80, 60, "map", $text_color);
  $filename = "resources/map/over32.png";
  ImagePNG($im);
  /* <!-- sprintf("%d.png", time()); /* <!--/home/www/web64 -->*/
  /* <!-- 
  ImagePNG($im); /*<!--,$filename
  printf("<img src='%s'> ", $filename);

  echo("<img src='");
  echo($filename);
  echo("'/>"); -->*/
  ImageDestroy($im);
?>
