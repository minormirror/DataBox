/*####################################################### MapNavigator ###################################################*/
function MapNavigator(){                  
  var mapDIV = document.createElement("div");
  var Ausgabebereich = document.getElementById("mappings");                
  mapDIV.style.backgroundColor = "#afafaf"; /*oder 'transparent' */
  mapDIV.style.position = "relative";

  //methode zum synchronisieren der MapNavigation setzt groesse und position des MapDiv
  this.setSizePos = function(xmax,ymax){ //xmax,ymax stellen die maximalwerte des aeusseren div dar
    var viewsizex = (window.innerWidth/xmax)*180;
    var viewsizey = (window.innerHeight/ymax)*130;
    var rel_x = ((1+window.pageXOffset)/xmax)*180;//problem : immer 0 wegen synchronisation----seite muß erst komplett aufgebaut sein-------------
    var rel_y = ((1+window.pageYOffset)/ymax)*130;
    
    /*if (window.pageXOffset != 0 && window.pageYOffset != 0) {
      var rel_x = ((1+window.pageXOffset)/xmax)*180;
      var rel_y = ((1+window.pageYOffset)/ymax)*130;
    } else {
      var rel_x = (1/xmax)*180;
      var rel_y = (1/ymax)*130;
    }*/
    
    mapDIV.style.width = viewsizex+"px";
    mapDIV.style.height = viewsizey+"px";
    mapDIV.style.left = rel_x+"px";
    mapDIV.style.top = rel_y+"px";
    
  }

  var siz = this.setSizePos(1762,1086);//------------------------------------------------------------daten werden von ajax benoetigt
  mapDIV.style.border = "1px solid";
  mapDIV.style.opacity = "0.45";  
      /*                #beispiel {
      filter:alpha(opacity=90); // Internet Explorer 
      -moz-opacity: 0.90; // Mozilla Browser 
      opacity: 0.90; // Opera 
      document.write('<link rel="stylesheet" type="text/css" href="linker1.css">');
      }*/
  mapDIV.style.display = "block";
  mapDIV.style.zIndex = "99";
  Ausgabebereich.appendChild(mapDIV);
  
  
  //methode zum navigieren des browserfensters innerhalb der map
  //muss an eventlistener gebunden werden
  this.jumpWindowView = function(xscroll,yscroll){
    jump_x = (mapDIV.style.left/180)*xscroll;
    jump_y = (mapDIV.style.top/130)*yscroll;
    window.scrollTo(jump_x,jump_y);
  }
 
}
