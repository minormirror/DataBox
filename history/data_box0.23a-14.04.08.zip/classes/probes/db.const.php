<?
$host = 'rdbms.strato.de';
$user = 'U320859';
$passwordd = 'saufen2805';
$db = 'DB320859';
?>