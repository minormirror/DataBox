<html><head><title>DataBox</title>

<script src="classes/js/func.Ajax.js" type="text/javascript"></script>
<script src="classes/js/class.IBDummyElement.js" type="text/javascript"></script>
<script src="classes/js/class.MapNavigator.js" type="text/javascript"></script> 
<script src="classes/js/class.Arrow.js" type="text/javascript"></script> 
<script src="classes/js/class.Control.js" type="text/javascript"></script> 
<script src="classes/js/class.Infobox.js" type="text/javascript"></script>
<script src="classes/js/func.Databox.js" type="text/javascript"></script>

<script type="text/javascript">
//var box_container;
function init(){  
  box_container = getControl();  
  document.onmousemove = box_container.onmousemove.bindAsEventListener(box_container);
  document.onmouseup = box_container.onmouseup.bindAsEventListener(box_container);
}

rufzeichen = new Image();
rufzeichen.src = "resources/buttons/ausrufezeichen_button.png";
rufzeichen_click = new Image();
rufzeichen_click.src = "resources/buttons/ausrufezeichen_button_click.png";

blitz = new Image();
blitz.src = "resources/buttons/blitz_button.png";
blitz_click = new Image();
blitz_click.src = "resources/buttons/blitz_button_click.png";

frage = new Image();
frage.src = "resources/buttons/frage_button.png";
frage_click = new Image();
frage_click.src = "resources/buttons/frage_button_click.png";

neues_div = new Image();
neues_div.src = "resources/buttons/neues_div_button.png";
neues_div_click = new Image();
neues_div_click.src = "resources/buttons/neues_div_button_click.png";


function Bildwechsel (Bildnr, Bildobjekt) {
  window.document.images[Bildnr].src = Bildobjekt.src;
}
</script>

<link href="classes/table_stylesheet.css" rel="stylesheet" type="text/css">
<link rel="addr icon" href="resources/favico.ico"/>
</head>
<body onLoad="init()" onChange="alert('tesdt');" style = "background-color:#c4c4c4"> 
   	<!--
	<input type="button" value="neu" onClick="box_container.addTextBox()" />
	-->
  <div id="eventbox" style ="width:500px; background-color:#fffaac; border:solid 1px #000000;">.</div>
  <div id="statebox" style ="width:500px; background-color:#fffaac; border:solid 1px #000000;">.</div>
  <div id="infobox" style ="width:500px; background-color:#fffaac; border:solid 1px #000000;">.</div>
  <div id="menu" class="mendiv_pos" >
  
  <table align = "center" class="tabl_box" cellpadding="0px" cellspacing="0px">
    <tr>
      <td class="top_lo"></td>
      <td class="top_o"></td>    
      <td class="top_re"></td>
    </tr>
    <tr>
      <td class="mid_l"></td>
      <td class="mid">      
        <table align = "center" class="in_tabl_box" cellpadding="0px" cellspacing="0px">
        	<tr>
        	  <!-- /* hier beginnen die Menue Komponenten innerhalb des rahmens */ -->
         	  <td onmousedown="Bildwechsel(0, neues_div_click)" onmouseup="Bildwechsel(0, neues_div)" onmouseout="Bildwechsel(0, neues_div)" onclick="box_container.addTextBox()">
        	    <IMG src="resources/buttons/neues_div_button.png" title="neuer beitrag"></td>        	
  	        <td onmousedown="Bildwechsel(1, rufzeichen_click)" onmouseup="Bildwechsel(1, rufzeichen)" onmouseout="Bildwechsel(1, rufzeichen)">
    	        <IMG src="resources/buttons/ausrufezeichen_button.png" title="zustimmung" ></td>
            <td onmousedown="Bildwechsel(2, blitz_click)" onmouseup="Bildwechsel(2, blitz)" onmouseout="Bildwechsel(2, blitz)">
              <IMG src="resources/buttons/blitz_button.png" title="widerspruch"></td>
        	  <td onmousedown="Bildwechsel(3, frage_click)" onmouseup="Bildwechsel(3, frage)" onmouseout="Bildwechsel(3, frage)">
    	        <IMG src="resources/buttons/frage_button.png" title="frage"></td>
          </tr>
      	  <tr>
        	  <td colspan="4">
         	    <div class="navcard" id="mappings">
         	    <!--/* hier befindet sich die Navigations Map */ -->
              </div>                  
        	  </td>
    	    </tr> 
        </table>    
      </td>
      <td class="mid_r"></td>
  </tr>
  <tr>
    <td class="bot_lo"></td>
    <td class="bot"></td>
    <td class="bot_re"></td>
  </tr>
</table>
</div>
<div id="cont" ></div>
</body>
</html>
