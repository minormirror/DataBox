<html><head><title>DataBox</title>

<script src="classes/js/class.Ajax.js" type="text/javascript"></script>
<script src="classes/js/class.IBDummyElement.js" type="text/javascript"></script>
<script src="classes/js/class.MapNavigator.js" type="text/javascript"></script> 
<script src="classes/js/class.Arrow.js" type="text/javascript"></script> 
<script src="classes/js/class.Control.js" type="text/javascript"></script> 
<script src="classes/js/class.Infobox.js" type="text/javascript"></script>
<script src="classes/js/func.Databox.js" type="text/javascript"></script>

<link href="classes/table_stylesheet.css" rel="stylesheet" type="text/css">
<link rel="addr icon" href="resources/favico.ico"/>

</head>
<body onLoad="init()" style = "background-color:#f8faff"> 
   	<!-- background-color:#c4c4c4 edefff
	<input type="button" value="neu" onClick="box_container.addTextBox()" />
	-->
  <div id="eventbox" style ="width:500px; background-color:#fffaac; border:solid 1px #000000;">.</div>
  <div id="statebox" style ="width:500px; background-color:#fffaac; border:solid 1px #000000;">.</div>
  <div id="infobox" style ="width:500px; background-color:#fffaac; border:solid 1px #000000;">.</div>
  <? include_once("nav_menue.php"); ?>

<div id="cont" ></div>

</body>
</html>
